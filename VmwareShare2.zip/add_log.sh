#!/bin/bash

found_flag=false

function AddLogByCFile
{
	delete_lines=`grep -n -B1 "^{$" $1 | grep -E "=|#define|struct|enum" | awk -F  "[-:]" '{print $1}' | sort -nr`
#	echo delete_lines: $delete_lines

	all_lines=`grep -nE  -r "^{$" $1  | awk -F ":" '{print $1}' | sort -nr`
#	echo all lines: $all_lines

	LineNumbers=`grep -nE  -r "^{" $1 | awk -F ":" '{print $1}' | sort -nr`

	PrintLogString='\ \ \ \ pr_info("%s %s %d\\n", __FILE__, __FUNCTION__, __LINE__); '
	#PrintLogString='\ \ \ \ pr_info("%s %s %d\\n", __FILE__, __FUNCTION__, __LINE__); \\'

	for a in $all_lines
	do	
		found_flag=false
		for d in $delete_lines
		do
			let d++
			if [ $a -eq $d ]
			then
					#echo found $a
					#unset all_lines[i]
					found_flag=true
					break
			fi
		done
		#echo $found_flag
		if ! $found_flag; then
			let a++
			#echo $a

			sed -i "${a}i    ${PrintLogString}" $1
		fi
	done
}

cd /usr/src/linux-5.0.1/
#cd /usr/src/linux-5.0.1/drivers/firmware
#cd /usr/src/linux-5.0.1/arch/x86/events/amd
#cd /usr/src/linux-5.0.1/net/tipc
#cd /usr/src/linux-5.0.1/net/netfilter
pwd

CFiles=`find -type f | grep "\.c$" | xargs grep -Hrn $'\t'"pr\_" | awk -F "\:" '{print $1}' | uniq`
num=`echo $CFiles | wc | awk -F" " '{print $2}'`

i=1
for f in ${CFiles} 
do
    echo $i/$num: $f
    AddLogByCFile $f
    let i++
done


