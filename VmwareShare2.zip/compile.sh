echo tar -xf linux kernel
#cd /usr/src/
#mkdir temp
#cd temp
#cp ../linux-5.0.1.tar.gz .
#tar -xf linux-5.0.1.tar.gz


echo add log shell
/mnt/hgfs/VmwareShare/add_log.sh

cd /usr/src/linux-5.0.1
cp /mnt/hgfs/VmwareShare/bugs.c /usr/src/linux-5.0.1/arch/x86/kernel/cpu/bugs.c
cp /mnt/hgfs/VmwareShare/dib0070.c drivers/media/dvb-frontends/dib0070.c
cp /mnt/hgfs/VmwareShare/tuner-core.c /usr/src/linux-5.0.1/drivers/media/v4l2-core/tuner-core.c


echo compile
cd /usr/src/linux-5.0.1
make CONFIG_FRAME_WARN=2048 -j 16 2>&1 | tee log.txt 



